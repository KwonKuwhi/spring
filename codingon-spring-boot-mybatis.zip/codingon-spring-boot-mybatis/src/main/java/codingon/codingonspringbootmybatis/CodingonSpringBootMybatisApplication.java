package codingon.codingonspringbootmybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodingonSpringBootMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingonSpringBootMybatisApplication.class, args);
	}

}
