package codingon.codingonspringbootjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingonSpringBootJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
