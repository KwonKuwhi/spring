package codingon.codingonspringbootjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodingonSpringBootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingonSpringBootJpaApplication.class, args);
	}

}
