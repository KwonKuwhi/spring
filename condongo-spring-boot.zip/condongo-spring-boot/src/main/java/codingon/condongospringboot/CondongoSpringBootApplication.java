package codingon.condongospringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CondongoSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CondongoSpringBootApplication.class, args);
	}

}
