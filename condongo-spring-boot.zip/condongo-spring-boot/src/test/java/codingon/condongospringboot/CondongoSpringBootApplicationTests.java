package codingon.condongospringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CondongoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
